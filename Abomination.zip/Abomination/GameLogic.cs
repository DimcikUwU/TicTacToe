﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abomination
{
    public class GameLogic
    {
        public Player[,] GameGrid { get; private set; }
        public Player PlayerTurn { get; private set; }
        public int TurnsPassed { get; private set; }
        public bool GameOver { get; private set; }

        public event Action<int, int> MoveMade;
        public event Action<GameResult> GameEnded;
        public event Action GameRestarted;

        public GameLogic() 
        {
            GameGrid = new Player[3, 3];
            PlayerTurn = Player.X;
            TurnsPassed = 0;
            GameOver = false;
        }

        private bool CanPlay(int r, int c)
        {
            return !GameOver && GameGrid[r, c] == Player.None;
        }

        private bool FullGrid()
        {
            return TurnsPassed == 9;
        }

        private void PlayerSwitch()
        {
            if(PlayerTurn == Player.X) 
            {
                PlayerTurn= Player.O;            
            }
            else
            {
                PlayerTurn = Player.X;
            }
        }

        private bool AreSquaresMarked((int, int)[] squares, Player player)
        {
            foreach((int r, int c) in squares)
            {
                if (GameGrid[r,c] != player)
                {
                    return false;
                }
            }
            return true;
        }


        private bool WinningMove(int r, int c, out WinInfo winInfo)
        {
            //an array comtaining the square positions of the row where the move was made
            //and same thing for the column, MainDiagonal, AntiDiagonal
            (int, int)[] row = new[] { (r, 0), (r, 1), (r, 2) };
            (int, int)[] col = new[] { (0, c), (1, c), (2, c) };
            (int, int)[] mainD = new[] { (0, 0), (1, 1), (2, 2) };
            (int, int)[] antiD = new[] { (0, 2), (1, 1), (2, 0) };
          
            
            //if every square in one of arrays is marked by the player then taht player has won the game
            //if AreSquaresMarked return true we known that row r is full
            //logic is the same for all others conditions
            if (AreSquaresMarked(row, PlayerTurn))
            {
                winInfo = new WinInfo { Type = WinType.Row, Number = r };
                return true;
            }

            if (AreSquaresMarked(col, PlayerTurn))
            {
                winInfo = new WinInfo { Type = WinType.Column, Number = c };
                return true;
            }
            
            if(AreSquaresMarked(mainD, PlayerTurn))
            {
                winInfo = new WinInfo { Type = WinType.MainDiagonal };
                return true;
            }

            if (AreSquaresMarked(antiD, PlayerTurn))
            {
                winInfo = new WinInfo { Type = WinType.AntiDiagonal };
                return true;
            }

            winInfo = null;
            return false;

        }

     
        private bool DidMoveEndGame(int r, int c, out GameResult gameResult)
        {
            if(WinningMove(r, c, out WinInfo winInfo)) 
            {
                gameResult = new GameResult { Winner = PlayerTurn, WinInfo= winInfo };
                return true;
            }

            if (FullGrid())
            {
                gameResult = new GameResult { Winner = Player.None };
                return true;
            }

            gameResult = null;
            return false;
        }

        /// <summary>
        /// Makes the move.
        /// </summary>
        /// <param name="r">row.</param>
        /// <param name="c">column.</param>
        public void MakeMove(int r, int c)
        {
            if(!CanPlay(r, c))
            {
                return;
            }

            GameGrid[r, c] = PlayerTurn;
            TurnsPassed++;

            if (DidMoveEndGame(r, c, out GameResult gameResult))
            {
                GameOver = true;
                MoveMade?.Invoke(r, c);
                GameEnded?.Invoke(gameResult);
            }
            else
            {
                PlayerSwitch();
                MoveMade?.Invoke(r, c); 
            }

        }

        /// <summary>
        /// Restart the game.
        /// </summary>
        public void Reset()
        {
            GameGrid = new Player[3, 3];
            PlayerTurn = Player.X;
            TurnsPassed = 0;
            GameOver = false;   
            GameRestarted?.Invoke();
        }    

    }
}
