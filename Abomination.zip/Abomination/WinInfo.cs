﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abomination
{
    public class WinInfo
    {
        public WinType Type { get; set; }
        public int Number { get; set;}
    }
}
